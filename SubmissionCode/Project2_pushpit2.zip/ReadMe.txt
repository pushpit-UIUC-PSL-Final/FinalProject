For generating the resized images which are used in Question 1. Please run the script 'image_processor.py' after setting the appropriate parameters in the code.

extract_features.py: This code file is used to generate the feature set used in Question 2.
Project2_question1.ipynb: Notebook for Question 1
Project2_question2.ipynb: Notebok for Question 2

malignant_features.txt: Features extracted from malignant images as per question 2
benign_features.txt: Features extracted from benign images as per question 2

Please note: We were not able to put the resized images in the zip as coursera was not allowing that bigger zip to be submitted.
